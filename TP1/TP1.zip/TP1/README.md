# TODO:
### Semana 1:
- [x] Ex1
- [x] Ex2
- [x] Ex3
  
### Semana 2:
- [x] Ex4
- [x] Ex5
  
### Semana 3:
- [x] Ex6

### Semana 4:
- [x] Relatório

#### [Link do relatório](https://onedrive.live.comView.aspx?resid=14ADEE51745036AA!605&authkey=!Avn7mxRqc5OJcZE)
 
